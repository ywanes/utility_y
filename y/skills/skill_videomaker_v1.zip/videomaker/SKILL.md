---
name: videomaker
version: 1.0.0
description: Use quando o time de produto quiser um vídeo de treinamento/explicativo de qualquer módulo, tela ou fluxo de uma aplicação — conduz ping-pong de perguntas (módulo, URLs, público-alvo, brand book, entregáveis), varre o repo, captura a UI real com Playwright em HML e renderiza MP4 com Remotion (narração TTS, clipes webm e GIFs opcionais)
---

# Training Video Maker

Gera vídeos de treinamento profissionais de qualquer módulo de uma aplicação, no padrão
visual do golden example (`references/exemplo-dispensacao.md`).

## Hard rules (não negociáveis)

- ⛔ **Captura destrutiva NUNCA em PROD.** Toda captura roda em HML/homolog. A URL de PROD
  serve apenas como texto cosmético na barra do browser fake (`BRAND.urlBar no theme.ts`).
- ⛔ **Credenciais só de ambiente de teste**, gravadas em `.env` local gitignorado no diretório
  de trabalho do vídeo. Nunca commitar credenciais, nunca pedir senha de PROD.
- ⛔ **Dados pessoais nos vídeos**: sempre fictícios com dígito válido (ex. CPF `529.982.247-25`)
  ou ofuscados na própria tela.
- ✅ **Ações irreversíveis** (ex.: dispensar receita) consomem 1 dado de teste por take.
  Pedir a lista no ping-pong, marcar cada um como consumido e reportar no final.
- ✅ Clipes Playwright com `slowMo: 400` (convenção do time — vídeos assistíveis).
- ✅ Projeto Remotion sempre isolado (`node_modules` próprio, `.gitignore`); nada vai p/ deploy.
- ✅ **Nada é renderizado antes do storyboard aprovado** (Fase 4) e **nada é entregue antes
  do QA frame-a-frame passar** (Fase 7).

## Fase 0 — Pré-requisitos

Verificar e instruir o que faltar (não seguir sem resolver):

```bash
node --version    # 20+
python3 --version # 3.9+
ffmpeg -version   # brew install ffmpeg
```

`edge-tts` só é necessário se o usuário pedir narração (Fase 1): `pip3 install edge-tts`.

## Fase 1 — Ping-pong de descoberta

Perguntar UMA por vez (AskUserQuestion; multiple choice quando possível). Se já houver
resposta na mensagem inicial do usuário, não repetir a pergunta.

1. **Módulo/fluxo**: se o usuário não especificou, varrer o repo primeiro (Fase 2 parcial)
   e oferecer um menu dos módulos/telas detectados.
2. **URL de captura (HML)** — obrigatória. E **URL de PROD** (opcional) só para exibir na
   barra do browser fake.
3. **A área exige login?** Se sim: credenciais de TESTE (usuário informa; salvar em `.env`
   local gitignorado). Playwright salva `storageState.json` local para reutilizar na sessão.
4. **O fluxo tem ações irreversíveis/destrutivas?** Se sim: lista de dados de teste
   descartáveis (1 por take) — ex.: códigos frescos, registros de teste.
5. **Público-alvo** (farmacêutico, atendente, médico, gestor...) → define tom da copy,
   vocabulário e nível de detalhe.
6. **Brand book**: link/arquivo com cores+logo, OU "extrair do app" — nesse caso, capture a
   tela inicial e derive a paleta (cores dominantes de header/botões/links) para `theme.ts`.
7. **Entregáveis** (multi-select): MP4 editado / narração TTS / clipes webm crus / GIFs por passo.
8. **Idioma** (default pt-BR).

## Fase 2 — Varredura do repo

Entender o módulo no código: rotas/URLs, telas, estados de sucesso e ERRO, permissões,
textos reais de botões/labels. Objetivo: propor um roteiro completo incluindo casos de erro
que o usuário talvez não lembre (no golden example: CPF inválido, código inexistente,
documento que não é receita). Use subagents Explore para varreduras amplas.

## Fase 3 — Exploração ao vivo

Navegar a URL de HML com Playwright headless (ou Chrome cowork, se o usuário quiser assistir)
para confirmar seletores, textos e estados reais. **Nenhuma ação destrutiva nesta fase** —
somente leitura e navegação.

## Fase 4 — Storyboard + gate de aprovação

Apresentar o roteiro cena a cena em tabela: nº, tipo (Abertura/Passo/Caso de erro/Dica/
Resumo/Encerramento), título, texto na tela OU narração, o que aparece no browser
(screenshot/clipe), duração estimada. Total alvo: 60–120s.

**Aguardar OK explícito do usuário.** Só depois do OK: captura destrutiva e render.

## Fase 5 — Captura

1. Criar `docs/training-videos/<modulo>/` no projeto alvo e copiar `templates/remotion/`
   para `docs/training-videos/<modulo>/remotion-source/`.
2. Copiar `templates/capture-template.mjs` para `remotion-source/capture-all.mjs` e
   customizar: cenas do storyboard, seletores confirmados na Fase 3.
3. Rodar com o guard de ambiente:
   ```bash
   cd docs/training-videos/<modulo>/remotion-source
   npm install && npx playwright install chromium
   CAPTURE_BASE_URL=https://<hml> CAPTURE_CONFIRM_HML=1 node capture-all.mjs
   ```
4. Screenshots ficam em `public/shots/*.png` (`deviceScaleFactor: 2`). Clipes webm (se
   pedidos): contexts com `recordVideo` + `slowMo: 400`, salvos em `clips/`.
5. Anotar as dimensões reais de cada PNG (o `DIMS` do `Training.tsx` precisa delas):
   `node -e "..."` com `image-size` NÃO é necessário — use `ffprobe -v quiet -show_entries stream=width,height -of csv=p=0 arquivo.png`.

## Fase 6 — Montagem e render

1. Preencher `src/theme.ts` com as cores do brand book (Fase 1) e o bloco `BRAND`
   (nome do produto, URL cosmética, WhatsApp/canal de suporte).
2. Escrever `src/Training.tsx` com as cenas aprovadas, usando os componentes de `ui.tsx`
   (`Callout`, `Kicker`, `Bullet`, `BrowserShot`) e as cenas-modelo de `Training.tsx`
   (`IntroScene`, `ContentScene`, `CenteredScene`, `OutroScene`) e o `DIMS`
   com as dimensões reais dos PNGs.
3. **Narração TTS (se pedida):**
   ```bash
   pip3 install edge-tts
   # scenes.json: [{"id":"01-intro","text":"..."}]  (o texto de narração de cada cena)
   python3 tts.py scenes.json public/narration [--voice pt-BR-FranciscaNeural]
   # gera <id>.mp3 por cena + narration.json:
   #   {"<id>": {"file": "<id>.mp3", "durationSeconds": 12.34, "frames30fps": 371}}
   ```
   Copiar `templates/tts.py` para `remotion-source/tts.py`. O `narration.json` traz
   `frames30fps` por cena — use esse valor como duração da cena (`dur`) + ~20 frames de
   respiro, e adicione `<Audio src={staticFile('narration/<id>.mp3')} />` dentro da cena.
   Vozes: `pt-BR-AntonioNeural` (masc.) / `pt-BR-FranciscaNeural` (fem.) — perguntar
   preferência. Fallback sem internet (macOS): `say -v Luciana -o cena.aiff texto` +
   `ffmpeg -i cena.aiff cena.mp3`. Sem TTS possível: vídeo sem áudio (avisar o usuário).
4. Render:
   ```bash
   npx remotion render TrainingVideo out/treinamento-<modulo>.mp4 --concurrency=4
   ```
5. GIFs (se pedidos): `bash make-gifs.sh clips/<clipe>.webm gifs/<passo>.gif` (copiar
   `templates/make-gifs.sh`).

## Fase 7 — QA frame-a-frame (obrigatória)

1. Extrair frames: `ffmpeg -i out/treinamento-<modulo>.mp4 -vf fps=1/2 qa-frames/f%03d.png`
2. LER cada frame (tool Read) e revisar contra `templates/qa-checklist.md`.
3. Encontrou problema → corrigir `Training.tsx`/`theme.ts`/assets → re-renderizar → repetir.
4. Só entregar quando o checklist passar inteiro. Apagar `qa-frames/` depois.

## Entrega

Estrutura final em `docs/training-videos/<modulo>/`:

```
treinamento-<modulo>.mp4
clips/*.webm        # se pedidos
gifs/*.gif          # se pedidos
remotion-source/    # re-renderizável (sem node_modules no git)
README.md           # inventário + como re-renderizar + avisos (padrão do golden example)
```

Ao final, mova `remotion-source/out/*.mp4` para a raiz da entrega como `treinamento-<modulo>.mp4`,
e copie/renomeie os webms de `remotion-source/clips/` (o Playwright gera nomes aleatórios) para
`clips/` com nomes descritivos (`01-<passo>.webm`).

O `README.md` deve listar: o que é cada arquivo, roteiro de cenas, como re-renderizar,
aviso sobre captura destrutiva/PROD e dados de teste consumidos. Modelo: seção "README de
entrega" em `references/exemplo-dispensacao.md`.

Reportar ao usuário: caminho dos entregáveis, dados de teste consumidos, e (se aplicável)
sugestão de commit.

## Arquivos desta skill

- `templates/remotion/` — projeto Remotion generalizado (copiar como `remotion-source/`)
- `templates/capture-template.mjs` — captura Playwright (copiar como `capture-all.mjs`)
- `templates/tts.py` — narração edge-tts
- `templates/make-gifs.sh` — webm → GIF
- `templates/qa-checklist.md` — checklist da Fase 7
- `references/exemplo-dispensacao.md` — golden example (padrão de qualidade e README de entrega)
- `INSTALL.md` — guia de instalação e uso para o time de produto

## Changelog

- **1.0.0** (24/jul/2026) — versao inicial (= skill_videomaker_v1.zip): pipeline
  Playwright + edge-tts + Remotion validado 2x de ponta a ponta (smoke tests
  hello-world e hello-world-teste2 em ~/claude/tmp/training-videos/).
