# Golden example — Treinamento "Dispensação de Medicamento" (2026-07)

Primeiro vídeo gerado com este pipeline, no monorepo do produto
(`docs/qa/videos-dispensacao/`, branch `docs/dispensacao-training-video`).
Use como referência de qualidade, estrutura e tom.

## O que foi entregue
- `treinamento-dispensacao.mp4` — 1920×1080, ~84s, 14 cenas, sem áudio
- 3 clipes webm de QA (Playwright em HML, slowMo 400)
- `remotion-source/` re-renderizável + README de entrega

## Estrutura de cenas que funcionou (roteiro-modelo)
1. Abertura (título + público + logo)
2. Motivação ("Um cuidado a mais" — por que fazer)
3. Passos 1..3 (telas reais com kicker "Passo N" + instrução curta)
4. Cena de sucesso (tint verde, kicker "Pronto")
5. Transição "Casos do dia a dia" (tint âmbar)
6. Casos de erro numerados (CaseTag "CASO N DE 4", tint por severidade:
   vermelho=bloqueio, âmbar=validação, azul=informativo)
7. Dica de produtividade
8. Resumo "Em 3 passos"
9. Encerramento com suporte (WhatsApp)

## Lições aprendidas (aplicar sempre)
- **Frames de HML, URL de PROD**: capturar em homolog, mas exibir a URL de produção na
  barra do browser fake — o público veria a URL real no dia a dia.
- **Ações irreversíveis**: dispensar receita é single-use; cada take de sucesso consumiu
  um código fresco. Pedir lista de dados descartáveis ANTES de capturar.
- **slowMo 400** nos clipes: sem isso o vídeo fica rápido demais para treinar.
- **deviceScaleFactor 2** nos screenshots: sem isso o pan/zoom do Remotion fica borrado.
- **fullPage nos screenshots de conteúdo**: o pan vertical (Ken Burns) precisa da página
  inteira; só a tela inicial (form) foi viewport-only.
- **Projeto Remotion isolado**: `node_modules` próprio, nada no build do monorepo.
- **Casos de erro valem tanto quanto o caminho feliz**: metade das dúvidas do público-alvo
  é "e quando dá errado?" — o repo revela esses estados (validações, guards, mensagens).

## README de entrega (modelo)
O README.md junto do vídeo deve ter: propósito e público; inventário dos arquivos;
lista de cenas; como re-renderizar (npm install → recapturar opcional → remotion render);
aviso de captura destrutiva/PROD; dados de teste consumidos.
