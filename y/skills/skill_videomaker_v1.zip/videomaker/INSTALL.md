# Como instalar e usar (guia do time de produto)

## O que é
Uma skill do Claude Code que gera vídeos de treinamento de qualquer módulo de uma
aplicação: ela faz perguntas (qual módulo, link de homolog, público-alvo, cores da
marca...), navega na aplicação de verdade, captura as telas e monta um MP4 profissional.
Você não precisa saber programar — só responder às perguntas.

## Pré-requisitos (uma vez por máquina)
1. **Claude Code** instalado e logado (peça ajuda ao time de eng se necessário)
2. **Homebrew + ffmpeg**: `brew install ffmpeg`
3. **Node 20+** e **Python 3** (macOS já tem Python 3; Node: `brew install node`)

## Instalar a skill (uma vez)
A skill vive neste repositório em `.claude/skills/videomaker/`.

- **Para usar em QUALQUER projeto** (recomendado):
  ```bash
  cp -r <caminho-do-monorepo>/.claude/skills/videomaker ~/.claude/skills/
  ```
- **Para usar só em um projeto específico**:
  ```bash
  cp -r <caminho-do-monorepo>/.claude/skills/videomaker <projeto>/.claude/skills/
  ```

Feche e reabra o Claude Code depois de copiar.

## Usar
1. Abra o terminal na pasta do projeto do qual você quer o vídeo
2. Rode `claude` e digite:
   ```
   /videomaker quero um vídeo de treinamento do módulo X
   ```
3. Responda às perguntas (módulo, link de homolog, público-alvo, cores...). Tenha em mãos:
   - o **link de homolog** da tela (nunca dê senha de produção!)
   - **credenciais de TESTE**, se a tela exigir login
   - **dados de teste descartáveis**, se o fluxo grava algo definitivo
     (ex.: códigos de receita não usados)
4. Aprove o roteiro quando a skill apresentar (nada é gravado antes do seu OK)
5. O vídeo sai em `docs/training-videos/<modulo>/` no projeto

## Dicas
- Peça "com narração" se quiser voz em português (grátis, gerada localmente)
- Peça "com GIFs" para ter versões curtas de cada passo para colar em docs/WhatsApp
- Se o vídeo precisar de ajuste depois, peça direto: "aumente a duração da cena 3" —
  a skill re-renderiza sem recapturar nada
