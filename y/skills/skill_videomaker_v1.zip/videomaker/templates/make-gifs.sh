#!/usr/bin/env bash
# make-gifs.sh — converte clipe webm do Playwright em GIF com paleta otimizada.
# Uso: bash make-gifs.sh clips/01-fluxo.webm gifs/01-fluxo.gif [720]
set -euo pipefail

IN="$1"
OUT="$2"
W="${3:-720}"

mkdir -p "$(dirname "$OUT")"
PAL="$(mktemp "${TMPDIR:-/tmp}/palette.XXXXXX.png")"
trap 'rm -f "$PAL"' EXIT

ffmpeg -y -loglevel error -i "$IN" -vf "fps=12,scale=${W}:-1:flags=lanczos,palettegen" "$PAL"
ffmpeg -y -loglevel error -i "$IN" -i "$PAL" \
  -filter_complex "fps=12,scale=${W}:-1:flags=lanczos[x];[x][1:v]paletteuse" "$OUT"

echo "OK — $OUT ($(du -h "$OUT" | cut -f1))"
