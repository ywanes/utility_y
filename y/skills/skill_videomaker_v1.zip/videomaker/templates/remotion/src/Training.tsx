import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig, spring } from 'remotion';
import { C, FONT, BRAND } from './theme';
import { SceneBg, LeftPanel, Kicker, Title, Body, Bullet, BrowserShot, CaseTag } from './ui';

// PREENCHER: dimensões reais de cada PNG em public/shots/
// (ffprobe -v quiet -show_entries stream=width,height -of csv=p=0 arquivo.png)
const DIMS: Record<string, [number, number]> = {
  '01-exemplo.png': [1366, 1000],
};

// fade nas bordas de cada cena p/ suavizar cortes (+ narração opcional)
const Fade: React.FC<{ children: React.ReactNode; dur: number; audio?: string }> = ({ children, dur, audio }) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 10, dur - 10, dur], [0, 1, 1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  return (
    <AbsoluteFill style={{ opacity: o }}>
      {audio ? <Audio src={staticFile(`narration/${audio}`)} /> : null}
      {children}
    </AbsoluteFill>
  );
};

const Shot: React.FC<{ file: string; panFrom?: number; panTo?: number }> = ({ file, panFrom = 0, panTo = 1 }) => {
  const [w, h] = DIMS[file];
  return <BrowserShot src={`shots/${file}`} imgW={w} imgH={h} panFrom={panFrom} panTo={panTo} />;
};

const ContentScene: React.FC<{
  dur: number;
  kicker: string;
  kickerColor?: string;
  title: string;
  bullets?: string[];
  body?: string;
  file: string;
  panFrom?: number;
  panTo?: number;
  tint?: string;
  caseN?: number;
  audio?: string;
}> = ({ dur, kicker, kickerColor, title, bullets, body, file, panFrom, panTo, tint, caseN, audio }) => (
  <Fade dur={dur} audio={audio}>
    <SceneBg tint={tint}>
      <LeftPanel>
        {caseN ? <CaseTag n={caseN} total={4} /> : null}
        <Kicker color={kickerColor}>{kicker}</Kicker>
        <Title>{title}</Title>
        {body ? <Body>{body}</Body> : null}
        {bullets?.map((b, i) => (
          <Bullet key={i} delay={12 + i * 7} color={kickerColor ?? C.teal}>
            {b}
          </Bullet>
        ))}
      </LeftPanel>
      <Shot file={file} panFrom={panFrom} panTo={panTo} />
    </SceneBg>
  </Fade>
);

// ---- cenas especiais ----
const Logo: React.FC = () => (
  <div style={{ fontSize: 96, fontWeight: 800, letterSpacing: -2, fontFamily: FONT }}>
    <span style={{ color: C.blue }}>{BRAND.product}</span>
  </div>
);

const IntroScene: React.FC<{ dur: number; title: string; subtitle: string; audio?: string }> = ({
  dur,
  title,
  subtitle,
  audio,
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: f, fps, config: { damping: 200 } });
  return (
    <Fade dur={dur} audio={audio}>
      <SceneBg tint="#183a6d">
        <AbsoluteFill style={{ alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
          <div style={{ opacity: s, transform: `translateY(${interpolate(s, [0, 1], [24, 0])}px)` }}>
            <div style={{ color: C.teal, fontSize: 30, fontWeight: 800, letterSpacing: 6, textTransform: 'uppercase', marginBottom: 26 }}>
              {BRAND.tagline}
            </div>
            <div style={{ color: C.text, fontSize: 92, fontWeight: 800, letterSpacing: -2, lineHeight: 1.05 }}>
              {title}
            </div>
            <div style={{ color: C.muted, fontSize: 34, marginTop: 26 }}>
              {subtitle}
            </div>
            <div style={{ marginTop: 60 }}>
              <Logo />
            </div>
          </div>
        </AbsoluteFill>
      </SceneBg>
    </Fade>
  );
};

const CenteredScene: React.FC<{
  dur: number;
  kicker: string;
  title: string;
  bullets?: string[];
  tint?: string;
  color?: string;
  audio?: string;
}> = ({ dur, kicker, title, bullets, tint, color = C.teal, audio }) => (
  <Fade dur={dur} audio={audio}>
    <SceneBg tint={tint}>
      <AbsoluteFill style={{ alignItems: 'center', justifyContent: 'center', padding: '0 220px' }}>
        <div style={{ textAlign: 'center', width: '100%' }}>
          <Kicker color={color}>{kicker}</Kicker>
          <Title size={76}>{title}</Title>
          {bullets ? (
            <div style={{ display: 'inline-flex', flexDirection: 'column', textAlign: 'left', marginTop: 20 }}>
              {bullets.map((b, i) => (
                <Bullet key={i} delay={14 + i * 8} color={color}>
                  {b}
                </Bullet>
              ))}
            </div>
          ) : null}
        </div>
      </AbsoluteFill>
    </SceneBg>
  </Fade>
);

const WhatsAppMark: React.FC<{ size?: number }> = ({ size = 54 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="#fff">
    <path d="M16 3C9 3 3.5 8.5 3.5 15.5c0 2.4.7 4.7 2 6.7L3 29l7-1.8c1.9 1 4 1.6 6 1.6 7 0 12.5-5.5 12.5-12.5S23 3 16 3zm0 22.8c-1.8 0-3.6-.5-5.1-1.4l-.4-.2-4.1 1.1 1.1-4-.3-.4A10.3 10.3 0 015.7 15.5C5.7 9.8 10.3 5.2 16 5.2s10.3 4.6 10.3 10.3S21.7 25.8 16 25.8zm5.7-7.7c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2s-.8 1-1 1.2c-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.7.1-.1.3-.4.5-.6.1-.2.2-.3.3-.5.1-.2 0-.4 0-.6-.1-.2-.7-1.7-1-2.3-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.2.2 2.2 3.4 5.3 4.7.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.2-.6-.4z" />
  </svg>
);

const OutroScene: React.FC<{ dur: number; audio?: string }> = ({ dur, audio }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: f, fps, config: { damping: 200 } });
  const chip = spring({ frame: f - 16, fps, config: { damping: 140, mass: 0.7 } });
  return (
    <Fade dur={dur} audio={audio}>
      <SceneBg tint="#0f3b2e">
        <AbsoluteFill style={{ alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
          <div style={{ opacity: s, transform: `translateY(${interpolate(s, [0, 1], [22, 0])}px)` }}>
            <div style={{ color: C.teal, fontSize: 30, fontWeight: 800, letterSpacing: 6, textTransform: 'uppercase', marginBottom: 22 }}>
              Precisa de ajuda?
            </div>
            <div style={{ color: C.text, fontSize: 84, fontWeight: 800, letterSpacing: -1 }}>{BRAND.supportLabel}</div>
            {BRAND.supportContact ? (
              <>
                <div
                  style={{
                    marginTop: 48,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 22,
                    background: '#25D366',
                    color: '#04121f',
                    padding: '24px 46px',
                    borderRadius: 22,
                    fontSize: 48,
                    fontWeight: 800,
                    boxShadow: '0 24px 60px rgba(37,211,102,0.35)',
                    opacity: chip,
                    transform: `scale(${interpolate(chip, [0, 1], [0.9, 1])})`,
                  }}
                >
                  <WhatsAppMark size={58} />
                  {BRAND.supportContact}
                </div>
                <div style={{ color: C.muted, fontSize: 26, marginTop: 22 }}>WhatsApp do Suporte {BRAND.product}</div>
              </>
            ) : null}
            <div style={{ marginTop: 48 }}>
              <Logo />
            </div>
          </div>
        </AbsoluteFill>
      </SceneBg>
    </Fade>
  );
};

// ---- montagem ----
type Item = { dur: number; el: (d: number) => React.ReactNode };

// EXEMPLO — substituir pelas cenas do storyboard aprovado (Fase 4).
// Duração: sem TTS, ~150-240 frames/cena; com TTS, frames30fps do narration.json + ~20.
const SCENES: Item[] = [
  { dur: 150, el: (d) => <IntroScene dur={d} title="Título do Treinamento" subtitle="Subtítulo — o que a pessoa vai aprender" /> },
  {
    dur: 180,
    el: (d) => (
      <ContentScene
        dur={d}
        kicker="Passo 1"
        title="Título do passo"
        body="Instrução curta e direta do que fazer nesta tela."
        file="01-exemplo.png"
      />
    ),
  },
  { dur: 200, el: (d) => <OutroScene dur={d} /> },
];

export const TOTAL = SCENES.reduce((a, s) => a + s.dur, 0);

export const Training: React.FC = () => {
  let from = 0;
  return (
    <AbsoluteFill style={{ background: C.bg0 }}>
      {SCENES.map((s, i) => {
        const el = (
          <Sequence key={i} from={from} durationInFrames={s.dur}>
            {s.el(s.dur)}
          </Sequence>
        );
        from += s.dur;
        return el;
      })}
    </AbsoluteFill>
  );
};
