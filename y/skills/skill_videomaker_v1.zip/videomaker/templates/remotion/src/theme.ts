// PREENCHER com o brand book do cliente (Fase 1 do ping-pong) ou com a paleta
// extraída do próprio app. Os defaults abaixo são uma paleta neutra (azul + teal).
export const C = {
  bg0: '#0a1220', // fundo mais escuro (gradiente)
  bg1: '#0f1d33', // fundo intermediário
  panel: '#12233d',
  line: '#22375a',
  blue: '#2f6df6', // cor primária da marca
  teal: '#34d3aa', // cor de destaque/acento
  text: '#eaf1fb',
  muted: '#9db2cc',
  success: '#2fae6b',
  danger: '#e0574d',
  warn: '#f0a83a',
  white: '#ffffff',
};

// PREENCHER por vídeo:
export const BRAND = {
  product: 'Nome do Produto', // aparece no logo textual das cenas de abertura/encerramento
  tagline: 'Treinamento', // kicker da abertura, ex.: "Treinamento · Farmacêutico"
  urlBar: 'https://app.exemplo.com/rota', // URL COSMÉTICA exibida na barra do browser fake
  supportLabel: 'Fale com o Suporte',
  supportContact: '', // ex.: "(11) 90000-0000" — vazio = cena de suporte sem chip de contato
};

export const FONT =
  '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

export const FPS = 30;

// dimensões do "viewport" da janela de browser (área visível do screenshot)
export const SHOT_W = 1200;
export const SHOT_H = 812;
