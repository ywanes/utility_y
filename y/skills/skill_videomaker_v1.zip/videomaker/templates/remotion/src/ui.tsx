import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  Easing,
} from 'remotion';
import { C, FONT, SHOT_W, SHOT_H, BRAND } from './theme';

export const SceneBg: React.FC<{ children: React.ReactNode; tint?: string }> = ({ children, tint }) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(1200px 700px at 78% 12%, ${tint ?? '#16305a'}, ${C.bg1} 55%, ${C.bg0})`,
      fontFamily: FONT,
    }}
  >
    {children}
  </AbsoluteFill>
);

// entrada suave (fade + slide) baseada no frame local
export const useIn = (delay = 0, dist = 26) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - delay, fps, config: { damping: 200, mass: 0.7 } });
  return { opacity: s, transform: `translateY(${interpolate(s, [0, 1], [dist, 0])}px)` };
};

export const Kicker: React.FC<{ children: React.ReactNode; color?: string; delay?: number }> = ({
  children,
  color = C.teal,
  delay = 0,
}) => {
  const a = useIn(delay);
  return (
    <div
      style={{
        ...a,
        color,
        fontSize: 26,
        fontWeight: 800,
        letterSpacing: 4,
        textTransform: 'uppercase',
        marginBottom: 18,
      }}
    >
      {children}
    </div>
  );
};

export const Title: React.FC<{ children: React.ReactNode; size?: number; delay?: number }> = ({
  children,
  size = 68,
  delay = 4,
}) => {
  const a = useIn(delay);
  return (
    <div style={{ ...a, color: C.text, fontSize: size, fontWeight: 800, lineHeight: 1.05, letterSpacing: -1 }}>
      {children}
    </div>
  );
};

export const Body: React.FC<{ children: React.ReactNode; delay?: number; size?: number }> = ({
  children,
  delay = 10,
  size = 30,
}) => {
  const a = useIn(delay);
  return (
    <div style={{ ...a, color: C.muted, fontSize: size, lineHeight: 1.5, marginTop: 22, maxWidth: 620 }}>
      {children}
    </div>
  );
};

export const Bullet: React.FC<{ children: React.ReactNode; delay?: number; color?: string }> = ({
  children,
  delay = 0,
  color = C.teal,
}) => {
  const a = useIn(delay);
  return (
    <div style={{ ...a, display: 'flex', alignItems: 'flex-start', gap: 16, marginTop: 20 }}>
      <div
        style={{
          width: 16,
          height: 16,
          borderRadius: 8,
          background: color,
          marginTop: 10,
          flexShrink: 0,
          boxShadow: `0 0 18px ${color}`,
        }}
      />
      <div style={{ color: C.text, fontSize: 30, lineHeight: 1.4 }}>{children}</div>
    </div>
  );
};

// Painel de texto à esquerda
export const LeftPanel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div
    style={{
      position: 'absolute',
      left: 96,
      top: 0,
      bottom: 0,
      width: 560,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
    }}
  >
    {children}
  </div>
);

// Janela de browser com screenshot + pan vertical (Ken Burns)
export const BrowserShot: React.FC<{
  src: string;
  imgW: number;
  imgH: number;
  panFrom?: number; // 0 topo, 1 base
  panTo?: number;
  x?: number;
  y?: number;
}> = ({ src, imgW, imgH, panFrom = 0, panTo = 1, x = 712, y = 150 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scale = SHOT_W / imgW;
  const scaledH = imgH * scale;
  const overflow = Math.max(0, scaledH - SHOT_H);
  const t = interpolate(frame, [12, durationInFrames - 6], [panFrom, panTo], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.ease),
  });
  // shots curtos: centraliza no viewport; shots altos: pan vertical
  const translateY = overflow > 0 ? -overflow * t : (SHOT_H - scaledH) / 2;
  const enter = spring({ frame, fps: 30, config: { damping: 200 } });
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: SHOT_W,
        borderRadius: 16,
        overflow: 'hidden',
        boxShadow: '0 40px 90px rgba(0,0,0,0.55)',
        border: `1px solid ${C.line}`,
        opacity: enter,
        transform: `scale(${interpolate(enter, [0, 1], [0.98, 1])})`,
      }}
    >
      {/* barra do browser */}
      <div style={{ height: 46, background: '#0c1728', display: 'flex', alignItems: 'center', paddingLeft: 18, gap: 9 }}>
        <Dot c="#ff5f57" />
        <Dot c="#febc2e" />
        <Dot c="#28c840" />
        <div
          style={{
            marginLeft: 16,
            background: '#1a2942',
            color: '#8aa0bf',
            fontSize: 17,
            padding: '7px 16px',
            borderRadius: 8,
            fontFamily: FONT,
          }}
        >
          {BRAND.urlBar}
        </div>
      </div>
      {/* viewport */}
      <div style={{ width: SHOT_W, height: SHOT_H, overflow: 'hidden', background: '#eef2f7', position: 'relative' }}>
        <Img src={staticFile(src)} style={{ width: SHOT_W, height: scaledH, transform: `translateY(${translateY}px)` }} />
      </div>
    </div>
  );
};

const Dot: React.FC<{ c: string }> = ({ c }) => (
  <div style={{ width: 14, height: 14, borderRadius: 7, background: c }} />
);

// Callout (anel + rótulo) sobre a janela do browser. Coordenadas no espaço SHOT (1200x812), offset pela posição da janela.
export const Callout: React.FC<{
  cx: number;
  cy: number;
  w?: number;
  h?: number;
  label: string;
  color?: string;
  delay?: number;
  side?: 'left' | 'right' | 'top' | 'bottom';
  winX?: number;
  winY?: number;
}> = ({ cx, cy, w = 260, h = 70, label, color = C.teal, delay = 8, side = 'right', winX = 712, winY = 150 }) => {
  const frame = useCurrentFrame();
  const s = spring({ frame: frame - delay, fps: 30, config: { damping: 180, mass: 0.6 } });
  const pulse = 1 + 0.06 * Math.sin((frame - delay) / 6);
  const left = winX + cx;
  const top = winY + 46 + cy; // +46 = barra do browser
  const labelStyle: React.CSSProperties = { position: 'absolute', background: color, color: '#04121f', fontWeight: 800, fontSize: 22, padding: '10px 16px', borderRadius: 10, whiteSpace: 'nowrap', boxShadow: '0 10px 30px rgba(0,0,0,0.4)', fontFamily: FONT };
  const lp: React.CSSProperties =
    side === 'right'
      ? { left: left + w + 22, top: top + h / 2 - 26 }
      : side === 'left'
      ? { right: 1920 - (left - 22), top: top + h / 2 - 26 }
      : side === 'top'
      ? { left: left + w / 2 - 100, top: top - 60 }
      : { left: left + w / 2 - 100, top: top + h + 14 };
  return (
    <>
      <div
        style={{
          position: 'absolute',
          left,
          top,
          width: w,
          height: h,
          border: `4px solid ${color}`,
          borderRadius: 12,
          boxShadow: `0 0 26px ${color}`,
          opacity: s,
          transform: `scale(${pulse})`,
          transformOrigin: 'center',
        }}
      />
      <div style={{ ...labelStyle, ...lp, opacity: s, transform: `translateY(${interpolate(s, [0, 1], [10, 0])}px)` }}>
        {label}
      </div>
    </>
  );
};

// Selo de caso (canto superior esquerdo da janela)
export const CaseTag: React.FC<{ n: number; total: number; color?: string; delay?: number }> = ({
  n,
  total,
  color = C.blue,
  delay = 0,
}) => {
  const a = useIn(delay);
  return (
    <div style={{ ...a, display: 'inline-flex', alignItems: 'center', gap: 12, marginBottom: 22 }}>
      <div
        style={{
          background: color,
          color: '#fff',
          fontWeight: 800,
          fontSize: 22,
          width: 46,
          height: 46,
          borderRadius: 12,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {n}
      </div>
      <div style={{ color: C.muted, fontSize: 20, fontWeight: 700, letterSpacing: 2 }}>CASO {n} DE {total}</div>
    </div>
  );
};
