import React from 'react';
import { Composition } from 'remotion';
import { Training, TOTAL } from './Training';
import { FPS } from './theme';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="TrainingVideo"
    component={Training}
    durationInFrames={TOTAL}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
