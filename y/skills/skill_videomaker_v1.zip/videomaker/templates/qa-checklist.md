# QA frame-a-frame — checklist

Extrair 1 frame a cada ~2s (`ffmpeg -i video.mp4 -vf fps=1/2 qa-frames/f%03d.png`),
LER cada frame e verificar TODOS os itens. Qualquer ✗ → corrigir e re-renderizar.

## Texto e layout
- [ ] Nenhum título/bullet cortado ou com overflow fora do painel esquerdo
- [ ] Nenhum texto sobrepondo a janela do browser ou o Callout
- [ ] Fontes legíveis (nada menor que ~20px equivalente em 1080p)
- [ ] Copy sem erro de português; termos consistentes com a tela real

## Screenshots
- [ ] Screenshot nítido (@2x), sem blur de scale errado
- [ ] Pan (Ken Burns) mostra a região certa da tela no momento certo do texto
- [ ] Nenhum dado pessoal REAL visível (CPF/nome/telefone) — só fictício ou ofuscado
- [ ] URL na barra do browser fake é a URL combinada (PROD cosmética), sem host de HML vazando
- [ ] Nenhuma menção a ambiente/sistema interno indevido (ex.: nomes de staging, dados de debug)

## Cores e marca
- [ ] Cores conferem com o brand book informado (primária/acento nos kickers, bullets, chips)
- [ ] Logo/nome do produto correto na abertura e encerramento
- [ ] Contraste suficiente (texto muted legível sobre o fundo)

## Timing e áudio (se TTS)
- [ ] Cada cena dura o suficiente para ler tudo (ou até o fim da narração + respiro)
- [ ] Fades de entrada/saída suaves, sem corte seco no meio de animação
- [ ] Áudio sincronizado: a narração da cena N não vaza para a cena N+1
- [ ] Sem silêncio longo (>2s) dentro de cena com narração

## Encerramento
- [ ] Cena de suporte com contato correto (ou sem chip, se não informado)
- [ ] Resumo cobre os passos principais na ordem certa
