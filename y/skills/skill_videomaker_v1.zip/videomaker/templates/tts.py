#!/usr/bin/env python3
"""Narração TTS por cena — edge-tts (grátis, sem API key), vozes neurais pt-BR.

Uso:
    pip3 install edge-tts
    python3 tts.py scenes.json public/narration [--voice pt-BR-FranciscaNeural]

scenes.json: [{"id": "01-intro", "text": "Texto da narração...", "voice": "(opcional)"}]
Saída: <out_dir>/<id>.mp3 + <out_dir>/narration.json com durações (ffprobe) e frames a 30fps.

Fallback sem internet (macOS): say -v Luciana -o cena.aiff "texto" && ffmpeg -i cena.aiff cena.mp3
"""
import asyncio
import json
import pathlib
import subprocess
import sys

DEFAULT_VOICE = "pt-BR-AntonioNeural"  # masc.; fem.: pt-BR-FranciscaNeural
FPS = 30


async def synth(text: str, voice: str, out: pathlib.Path) -> None:
    import edge_tts

    await edge_tts.Communicate(text, voice).save(str(out))


def duration_seconds(path: pathlib.Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "quiet", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
        capture_output=True,
        text=True,
        check=True,
    )
    return float(r.stdout.strip())


def main() -> None:
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    scenes = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
    out_dir = pathlib.Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    voice = DEFAULT_VOICE
    if "--voice" in sys.argv:
        idx = sys.argv.index("--voice")
        if idx + 1 >= len(sys.argv):
            sys.exit("--voice requer um valor (ex.: pt-BR-FranciscaNeural)")
        voice = sys.argv[idx + 1]

    meta = {}
    for scene in scenes:
        mp3 = out_dir / f"{scene['id']}.mp3"
        asyncio.run(synth(scene["text"], scene.get("voice", voice), mp3))
        secs = duration_seconds(mp3)
        meta[scene["id"]] = {
            "file": mp3.name,
            "durationSeconds": round(secs, 3),
            "frames30fps": int(secs * FPS) + 1,
        }
        print(f"  {scene['id']}: {secs:.1f}s")

    (out_dir / "narration.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"OK — {len(meta)} cenas em {out_dir}/ (+ narration.json)")


if __name__ == "__main__":
    main()
