// capture-template.mjs — TEMPLATE de captura (Playwright). Customizar as CENAS abaixo
// com o storyboard aprovado. Screenshots -> public/shots/ ; clipes webm -> clips/.
//
// Uso:
//   CAPTURE_BASE_URL=https://<hml> CAPTURE_CONFIRM_HML=1 node capture-all.mjs
//
// ⛔ NUNCA aponte para produção com dados reais: passos de sucesso podem gravar
//    registros irreversíveis. O guard CAPTURE_CONFIRM_HML existe para te fazer pensar.
import { chromium } from 'playwright';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SHOTS_DIR = path.join(__dirname, 'public', 'shots');
const CLIPS_DIR = path.join(__dirname, 'clips');

const BASE = process.env.CAPTURE_BASE_URL;
if (!BASE) throw new Error('Defina CAPTURE_BASE_URL (URL de HML).');
if (process.env.CAPTURE_CONFIRM_HML !== '1')
  throw new Error('Confirme que a URL é de HML: rode com CAPTURE_CONFIRM_HML=1');
fs.mkdirSync(SHOTS_DIR, { recursive: true });
fs.mkdirSync(CLIPS_DIR, { recursive: true });

// Context para SCREENSHOTS (@2x, viewport desktop)
async function shotCtx(browser) {
  const ctx = await browser.newContext({
    viewport: { width: 1366, height: 900 },
    ignoreHTTPSErrors: true,
    deviceScaleFactor: 2,
    // Área com login? Descomente após gerar o storageState uma vez:
    // storageState: 'storageState.json',
    // Para GERAR o storageState uma vez (login manual/scriptado):
    //   const page = await ctx.newPage(); await page.goto(`${BASE}/login`); /* faça o login */
    //   await ctx.storageState({ path: 'storageState.json' });
  });
  const page = await ctx.newPage();
  page.setDefaultTimeout(25000);
  return { ctx, page };
}

// Context para CLIPES webm (slowMo 400 — convenção do time p/ vídeos assistíveis)
async function clipCtx(browser) {
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    ignoreHTTPSErrors: true,
    recordVideo: { dir: CLIPS_DIR, size: { width: 1280, height: 800 } },
  });
  const page = await ctx.newPage();
  page.setDefaultTimeout(25000);
  return { ctx, page };
}

async function settle(page) {
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(1200); // animações/fade-in
}

const run = async () => {
  const browser = await chromium.launch({ slowMo: 400 });

  // ---- EXEMPLO screenshot: substituir pelas cenas do storyboard ----
  {
    const { ctx, page } = await shotCtx(browser);
    await page.goto(`${BASE}/`, { waitUntil: 'domcontentloaded' });
    await settle(page);
    await page.screenshot({ path: `${SHOTS_DIR}/01-exemplo.png`, fullPage: true });
    await ctx.close();
  }

  // ---- EXEMPLO clipe webm: um fluxo completo assistível ----
  // {
  //   const { ctx, page } = await clipCtx(browser);
  //   await page.goto(`${BASE}/rota`, { waitUntil: 'domcontentloaded' });
  //   await page.fill('#campo', 'valor');
  //   await page.click('#botao');
  //   await settle(page);
  //   await ctx.close(); // o webm é salvo ao fechar o context
  // }

  await browser.close();
  console.log('OK — shots em public/shots/, clipes em clips/');
};
run().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
