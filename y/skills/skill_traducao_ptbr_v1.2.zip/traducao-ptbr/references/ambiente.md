# Ambiente desta máquina (host do "porteiro") e setup do Buzz

## Regras do porteiro (segurança de rede/processos)

- **Só `curl` tem saída de rede no host.** Qualquer outro processo que abra HTTPS
  (pip, python, apt de usuário) é MORTO silenciosamente — o shell inteiro morre com
  exit 1, sem mensagem de erro. Nunca instalar nada no host.
- **Processos longos/ociosos morrem em ~20–60s**: `docker wait`, `docker logs -f`,
  loops com sleep, busy-waits, Monitor, e até comandos interativos digitados pelo
  usuário no terminal (`docker run` foreground → "Killed").
- **O daemon Docker é imune** (e tem egress normal). Portanto: trabalho pesado sempre
  em container detached (`docker run -d` / `docker exec -d`), acompanhamento com
  comandos one-shot rápidos (`docker inspect -f '{{.State.Status}}'`).
- **Espera longa (padrão do despertador)**: waiters em background
  (`until [ cond ]; do sleep 5; done` via run_in_background) morrem em ~1–2 min, mas a
  morte gera notificação → re-armar a cada morte. Status "completed" = condição
  satisfeita; "failed" = foi morto, re-armar.
- Cliente docker de operação longa (ex.: `docker commit` de camada grande) também
  morre → rodar o PRÓPRIO cliente dentro de um container:
  `docker run -d -v /var/run/docker.sock:/var/run/docker.sock docker:cli commit ...`
- Docker precisa de `sudo -n` (grupo sudo NOPASSWD; socket nega acesso direto).
- `docker build` usa o builder legado e o cliente morre no meio → nunca usar build;
  usar run -d + script + commit.
- Porta 9000 fechada = porteiro desligado → avisar o usuário, que ele liga.

## Hardware/SO

- 3 vCPUs ("Virtual CPU" sem AVX2/cx16 — numpy 2.x crasha com erro "X86_V2";
  usar numpy<2), 9 GB RAM, Python do sistema 3.14, sem ffmpeg no host.

## Reconstruir a imagem buzz:1.4.4 (se não existir)

```bash
sudo docker run -d --name buzzbox \
  -v ~/claude/tmp:/data -v <pasta-desta-skill>/scripts:/setup:ro \
  -e QT_QPA_PLATFORM=offscreen python:3.12-slim sleep infinity
sudo docker exec -d buzzbox bash /setup/build3.sh
# poll até: sudo docker exec buzzbox test -f /tmp/BUILD_OK  (~15-20 min)
sudo docker run -d --name committer -v /var/run/docker.sock:/var/run/docker.sock \
  docker:cli commit -c 'ENV QT_QPA_PLATFORM=offscreen' -c 'ENTRYPOINT ["buzz"]' \
  -c 'WORKDIR /data' buzzbox buzz:1.4.4
# poll até committer sair (exited); ~10 min. Depois: docker rm buzzbox committer
```

Notas do build3.sh: `build-essential` é obrigatório (ctc_segmentation/diffq/texterrors
compilam do fonte); torch instalado como 2.8.0+cpu do índice
`https://download.pytorch.org/whl/cpu` (satisfaz o pin ==2.8.0 do buzz e evita ~5 GB
de wheels CUDA); buzz-captions==1.4.4 exige Python >=3.12,<3.13.

Armadilha: `finalil/buzz` do Docker Hub é OUTRO projeto ("buzzng") — não é o Buzz.

## CLI do buzz (referência)

```
buzz add [opções] arquivo...
  -t transcribe|translate      (translate = só para inglês)
  -m whisper|whispercpp|huggingface|fasterwhisper|openaiapi
  -s tiny|base|small|medium|large
  -l <código de idioma>        (idioma do áudio; vazio = detectar)
  -p "prompt inicial"          (termos/nomes esperados — melhora o ASR)
  --word-timestamps            (1 palavra por cue — para sincronia exata)
  --vtt --srt --txt --hide-gui
```

Benchmark (74 min de vídeo): small ≈ 1h30; medium ≈ 3–4x mais.
