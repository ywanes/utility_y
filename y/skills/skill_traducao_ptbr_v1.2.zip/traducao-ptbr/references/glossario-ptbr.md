# Glossário para tradução pt-BR (jargão de TI brasileiro)

Regra geral: manter em inglês os termos que o mercado de TI brasileiro usa em inglês;
traduzir o resto naturalmente. Nomes próprios nunca se traduzem.

## Mantém em inglês (como o dev brasileiro fala)

Linguagem/plataforma: bytecode, garbage collector / GC, JIT, JVM, JDK, JRE,
applet, servlet, thread, runtime, framework, library só quando for nome (ex.: "a
lib"), classpath, sandbox, plugin, script, API, endpoint, string, array, hash,
loop, callback, cast, parser, wrapper, boilerplate.

Sistema/infra: shell, terminal, prompt, kernel, driver, firmware, hardware,
software, host, server (ou servidor), cluster, container, pipeline, cache, log,
buffer, socket, proxy, firewall, gateway, root, sudo, daemon, mount, path.

Fluxo de trabalho: deploy, release, build, commit, branch, merge, pull request,
push, rollback, patch, debug, stack trace, mock, refactoring (ou refatoração),
code review, backlog, sprint, milestone, codebase, feature, bug, hotfix.

Rede/dados: upload, download, login/logout, token, backup, streaming, byte, bit,
timestamp, payload, request/response (ou requisição/resposta).

Mercado/geral: open source, browser (ou navegador), cloud, backend, frontend,
full stack, embedded (ou embarcado), set-top box, workstation, mainframe,
startup, enterprise, big techs, hype, overhead, legacy (ou legado), benchmark,
briefing, licença GPL.

## Traduz
- garbage collection → coleta de lixo (1ª menção: "coleta de lixo (garbage collection)")
- memory leak → vazamento de memória
- write once, run anywhere → "escreva uma vez, rode em qualquer lugar" (manter original na 1ª menção)
- programming language → linguagem de programação
- virtual machine → máquina virtual
- compiler → compilador
- library → biblioteca
- development kit → kit de desenvolvimento
- open-sourced → aberto o código / liberado como open source

## Nomes próprios (nunca traduzir)
Sun Microsystems, James Gosling, Scott McNealy, Bill Joy, Patrick Naughton,
Green Project/Green Team, Oak, FirstPerson, HotJava, Netscape, HotSpot,
J2EE/Java EE, Jakarta, Tomcat, Apache, JCP (Java Community Process),
Oracle, Android, OpenJDK, Star7, Duke.

## Estilo
- Registro: documentário — natural, direto, sem formalidade excessiva.
- "you" genérico → "você" ou impessoal.
- Máx ~42 caracteres por linha, 2 linhas por cue (padrão legendagem).
