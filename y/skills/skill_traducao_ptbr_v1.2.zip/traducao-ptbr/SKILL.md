---
name: traducao-ptbr
description: Gera legenda .vtt em pt-BR (jargão de TI, cues curtos, sincronia por palavra) a partir de um vídeo/áudio, usando o Buzz (faster-whisper) em Docker. Usar quando o usuário pedir para transcrever, legendar ou traduzir vídeo/áudio para português ("legenda", "vtt", "transcrever", "buzz", "whisper").
version: 1.2.0
---

# Legenda pt-BR com Buzz + tradução com jargão de TI

Pipeline completo: transcrição (Buzz/faster-whisper em Docker) → tradução pt-BR
sentença a sentença (você, o modelo, traduz usando o glossário) → retranscrição com
timestamps por palavra → alinhamento e quebra em cues curtos com tempo medido.

## Pré-requisitos e restrições desta máquina (LER PRIMEIRO)

1. **Só `curl` tem rede no host.** pip/apt/python-HTTPS são mortos silenciosamente
   pelo "porteiro". Nunca instale nada no host — tudo via Docker.
2. **Processos longos/ociosos morrem em ~20–60s**, inclusive comandos interativos do
   usuário (`docker run` foreground → "Killed"). Regra: trabalho pesado SEMPRE em
   container **detached** (`docker run -d` / `docker exec -d`); acompanhar com polls
   one-shot (`docker inspect -f '{{.State.Status}}'`). Para esperar, use waiters em
   background re-armados a cada morte (a morte gera notificação; status "completed" =
   condição satisfeita). Detalhes em `references/ambiente.md`.
3. Docker exige `sudo -n`. A imagem **`buzz:1.4.4`** (10,7 GB) deve existir
   (`sudo docker images | grep buzz`). Se não existir, siga `references/ambiente.md`
   seção "Reconstruir a imagem".
4. `finalil/buzz` do Docker Hub NÃO é o Buzz — não usar.

## Passo a passo

### 1. Preparar e detectar idioma

- O arquivo precisa estar em `~/claude/tmp/` (montado como `/data`).
- Se o idioma do áudio for desconhecido, detecte com um trecho de 60s
  (`scripts/detect-lang.sh` como referência, modelo `tiny` — ~2 min).
- Se o áudio já for pt-BR: transcreva direto com `--language pt` e um `--prompt`
  com termos do assunto; pule a tradução (passos 3) e vá ao 4–5 para encurtar cues.

### 2. Transcrever (idioma original)

```bash
sudo -n docker run -d --name buzzjob-$(date +%s) -v ~/claude/tmp:/data buzz:1.4.4 \
  add --task transcribe --model-type fasterwhisper --model-size small \
  --language en --prompt "TERMOS DO ASSUNTO AQUI" --vtt --hide-gui /data/ARQUIVO
```

- Modelo `small` ≈ 1h30 para 74 min de vídeo nesta VM (3 vCPUs); `medium` 3–4x mais.
- `--prompt`: liste nomes próprios e termos técnicos esperados (melhora muito o ASR).
- Poll: `sudo -n docker inspect -f '{{.State.Status}}' <nome>` até `exited`.
- Saída: `~/claude/tmp/ARQUIVO (transcribed on DATA).vtt` — copie para `NOME.en.vtt`.

### 3. Traduzir para pt-BR (você traduz, não o whisper)

O whisper NÃO traduz para português. Leia o VTT em inglês e escreva o VTT pt-BR
**mantendo os timestamps idênticos** e traduzindo **sentença a sentença** (isso é
obrigatório para o alinhamento do passo 5 — cada sentença EN vira exatamente uma
sentença PT, na mesma ordem). Regras:

- Aplique `references/glossario-ptbr.md`: jargão de TI fica em inglês (bytecode,
  garbage collection, thread, deploy, runtime, applet...), nomes próprios intactos.
- Corrija erros do ASR pelo contexto ("cobalt"→COBOL, "Cobra"→CORBA,
  "parole scripts"→scripts Perl, "Certlet"→Servlet...).
- Valide ao final: mesmo nº de cues, timestamps idênticos, header WEBVTT
  (use um script python rápido — rede não é necessária).
- Salve como `NOME.pt.blocos.vtt` (blocos longos, intermediário).

### 4. Retranscrever com timestamps por palavra

Mesmo comando do passo 2 adicionando `--word-timestamps` (mesma duração de
processamento). Gera VTT com UMA palavra por cue — a fonte da sincronia exata.
Renomeie para `NOME.en.words.vtt`.

### 5. Alinhar e gerar cues curtos

```bash
python3 scripts/align_vtt.py NOME.en.words.vtt NOME.en.vtt NOME.pt.blocos.vtt SAIDA.vtt
```

O script casa as palavras (difflib, bloco a bloco) com o texto EN, extrai início/fim
REAL de cada sentença, aplica às sentenças PT 1:1 e empacota em cues de ≤84 chars
(2 linhas de ≤47), agrupando curtas e dividindo longas na vírgula. Onde a contagem de
sentenças PT≠EN num bloco, cai em proporção local (informa a estatística ao final).

**Atalho** (sem sincronia exata, dispensa o passo 4): `python3 scripts/split_vtt.py
NOME.pt.blocos.vtt SAIDA.vtt` — quebra proporcional ao texto; desliza até ±1s dentro
de cada bloco de ~30s.

### 6. Entregar

- Nomeie o VTT final como `NomeDoVideo.ext.vtt` (ex.: `Filme.webm.vtt`) — players
  carregam automaticamente pelo nome-base do vídeo.
- Valide: cues em ordem crescente, start<end, cobertura até o fim da fala
  (créditos/música sem fala ficam sem cue — é o esperado).
- Limpe os containers `buzzjob-*` (`sudo docker rm`).
- **Apague os intermediários** — a entrega é só e somente só o VTT final. Remova
  `NOME.en.vtt`, `NOME.en.words.vtt`, `NOME.pt.blocos.vtt` e o VTT bruto
  `ARQUIVO (transcribed on ...).vtt`. Só mantenha se o usuário pedir explicitamente
  (ex.: revisão futura da tradução de um vídeo longo — retranscrever custa horas).

## Estimativas (VM 3 vCPUs sem AVX2)

| Etapa | Duração p/ 74 min de vídeo |
|---|---|
| Detecção de idioma (tiny, 60s) | ~2 min |
| Transcrição small | ~1h30 |
| Tradução (modelo, 157 blocos) | minutos |
| Retranscrição c/ word-timestamps | ~1h30 |
| Alinhamento + quebra | segundos |

## Changelog

- **1.2.0** (24/jul/2026) — entrega passa a ser só o VTT final: passo 6 agora manda
  apagar os intermediários (`.en.vtt`, `.en.words.vtt`, `.pt.blocos.vtt`, VTT bruto),
  salvo pedido explícito do usuário (feedback do teste 2).

- **1.1.0** (24/jul/2026) — glossário expandido de 44 para ~100 termos em 5
  categorias (faltavam infra/dev: shell, terminal, log, cache, container...).
- **1.0.0** (24/jul/2026) — versão inicial: pipeline completo validado no
  documentário The Java Story (74 min, 1.023 cues, 86% com tempo medido).
