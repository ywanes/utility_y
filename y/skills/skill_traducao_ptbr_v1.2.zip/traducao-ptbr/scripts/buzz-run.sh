#!/bin/bash
# Transcreve um vídeo/áudio de ~/claude/tmp com o Buzz, em background (sobrevive ao porteiro).
# Uso: ./buzz-run.sh <arquivo-em-~/claude/tmp> [idioma] [modelo]
# Ex.:  ./buzz-run.sh The_Java_Story.webm en small
#       ./buzz-run.sh reuniao.mp4 pt medium
set -e
F="${1:?informe o arquivo (dentro de ~/claude/tmp)}"
L="${2:-en}"
S="${3:-small}"
[ -f "$HOME/claude/tmp/$F" ] || { echo "ERRO: ~/claude/tmp/$F nao existe"; exit 1; }
NAME="buzzjob-$(date +%s)"
sudo docker run -d --name "$NAME" -v "$HOME/claude/tmp:/data" buzz:1.4.4 \
  add --task transcribe --model-type fasterwhisper --model-size "$S" \
  --language "$L" --vtt --hide-gui "/data/$F"
echo "Rodando em background no container: $NAME"
echo "Acompanhe:   sudo docker ps --filter name=$NAME"
echo "Terminou quando o container sumir do 'docker ps' e o .vtt aparecer em ~/claude/tmp/"
echo "Log:         sudo docker logs $NAME | tail"
echo "Limpar:      sudo docker rm $NAME   (depois que terminar)"
