#!/bin/bash
set -ex
exec > /tmp/build.log 2>&1
apt-get update
apt-get install -y --no-install-recommends \
    ffmpeg build-essential \
    libgl1 libegl1 libopengl0 libxkbcommon0 libglib2.0-0 \
    libfontconfig1 libdbus-1-3 libportaudio2 libsndfile1
rm -rf /var/lib/apt/lists/*
pip install --no-cache-dir torch==2.8.0+cpu torchaudio==2.8.0+cpu --index-url https://download.pytorch.org/whl/cpu
pip install --no-cache-dir buzz-captions==1.4.4
buzz --version || true
touch /tmp/BUILD_OK
echo BUILD_OK
