#!/usr/bin/env python3
"""Alinha sentenças pt-BR aos tempos exatos das palavras e gera cues curtos.

Uso: align_vtt.py <en.words.vtt> <en.vtt> <pt.blocos.vtt> <saida.vtt>

  en.words.vtt   VTT gerado pelo buzz com --word-timestamps (1 palavra/cue)
  en.vtt         VTT em inglês (blocos, mesma transcrição SEM word-timestamps)
  pt.blocos.vtt  Tradução pt-BR com MESMOS timestamps/blocos do en.vtt,
                 traduzida sentença a sentença (mapa 1:1)
  saida.vtt      Legenda final: cues <=84 chars (2 linhas <=47), tempo medido
"""
import re, sys, textwrap, difflib

if len(sys.argv) != 5:
    sys.exit(__doc__)
WORDS_VTT, EN_VTT, PT_VTT, OUT = sys.argv[1:5]

MAX_CHARS = 84
MIN_DUR = 0.8

def ts2s(t):
    h, m, s = t.split(":")
    return int(h)*3600 + int(m)*60 + float(s)

def s2ts(x):
    h = int(x // 3600); x -= h*3600
    m = int(x // 60); x -= m*60
    return f"{h:02d}:{m:02d}:{x:06.3f}"

def parse_vtt(path):
    blocks = re.split(r'\n\n+', open(path).read().strip())
    cues = []
    for b in blocks[1:]:
        lines = b.split("\n")
        m = re.match(r'^(\S+) --> (\S+)$', lines[0])
        if m:
            cues.append((ts2s(m.group(1)), ts2s(m.group(2)), " ".join(lines[1:]).strip()))
    return cues

def norm(w):
    return re.sub(r'[^a-z0-9]', '', w.lower())

def sentences(text):
    parts = re.split(r'(?<=[.!?…])\s+', text.strip())
    return [p for p in parts if p]

words = [(s, e, t) for s, e, t in parse_vtt(WORDS_VTT) if t]
en_blocks = parse_vtt(EN_VTT)
pt_blocks = parse_vtt(PT_VTT)
assert len(en_blocks) == len(pt_blocks), \
    f"blocos EN ({len(en_blocks)}) != PT ({len(pt_blocks)}) — traducao deve manter os blocos"

def words_in(start, end):
    return [w for w in words if start - 0.5 <= (w[0]+w[1])/2 <= end + 0.5]

cues_out = []
stat_exact = stat_prop = 0

for (bs, be, ben), (_, _, bpt) in zip(en_blocks, pt_blocks):
    en_sents = sentences(ben)
    pt_sents = sentences(bpt)
    bw = words_in(bs, be)
    sent_times = None
    if bw:
        old_tokens, sent_idx = [], []
        for i, s in enumerate(en_sents):
            for tok in s.split():
                old_tokens.append(norm(tok)); sent_idx.append(i)
        new_tokens = [norm(w[2]) for w in bw]
        sm = difflib.SequenceMatcher(None, old_tokens, new_tokens, autojunk=False)
        tok_time = [None] * len(old_tokens)
        for a, b, size in sm.get_matching_blocks():
            for k in range(size):
                tok_time[a+k] = (bw[b+k][0], bw[b+k][1])
        last = (bs, bs)
        for i in range(len(tok_time)):
            if tok_time[i] is None:
                tok_time[i] = last
            else:
                last = tok_time[i]
        sent_times = []
        for i in range(len(en_sents)):
            ts = [tok_time[j] for j in range(len(old_tokens)) if sent_idx[j] == i]
            sent_times.append((ts[0][0], ts[-1][1]) if ts else None)
    if sent_times and len(pt_sents) == len(en_sents):
        stat_exact += 1
        pairs = list(zip(pt_sents, sent_times))
    else:
        stat_prop += 1
        total = sum(len(s) for s in pt_sents) or 1
        t = bs; pairs = []
        for s in pt_sents:
            dur = (be - bs) * len(s) / total
            pairs.append((s, (t, min(be, t + dur))))
            t += dur
    i = 0
    while i < len(pairs):
        s, (st, en) = pairs[i]
        j = i + 1
        while j < len(pairs) and len(s) + 1 + len(pairs[j][0]) <= MAX_CHARS:
            s = s + " " + pairs[j][0]
            en = pairs[j][1][1]
            j += 1
        if len(s) <= MAX_CHARS:
            cues_out.append((st, en, s))
        else:
            chunks, cur = [], ""
            for piece in re.split(r'(?<=,)\s+', s):
                if cur and len(cur) + 1 + len(piece) > MAX_CHARS:
                    chunks.append(cur); cur = piece
                else:
                    cur = f"{cur} {piece}".strip()
            if cur: chunks.append(cur)
            final = []
            for p in chunks:
                if len(p) <= MAX_CHARS:
                    final.append(p); continue
                ws, cur = p.split(), ""
                for w in ws:
                    if cur and len(cur)+1+len(w) > MAX_CHARS:
                        final.append(cur); cur = w
                    else:
                        cur = f"{cur} {w}".strip()
                if cur: final.append(cur)
            total = sum(len(c) for c in final)
            t = st
            for k, c in enumerate(final):
                dur = max(MIN_DUR, (en - st) * len(c) / total)
                ce = en if k == len(final)-1 else min(en, t + dur)
                cues_out.append((t, ce, c))
                t = ce
        i = j

for i in range(1, len(cues_out)):
    ps, pe, _ = cues_out[i-1]
    cs, ce, ct = cues_out[i]
    if cs < pe:
        cues_out[i] = (pe, max(ce, pe + 0.3), ct)

def wrap2(text):
    if len(text) <= 42: return text
    for w in range(42, 60):
        lines = textwrap.wrap(text, w)
        if len(lines) <= 2:
            for w2 in range((len(text)+1)//2, w):
                l2 = textwrap.wrap(text, w2)
                if len(l2) == 2: return "\n".join(l2)
            return "\n".join(lines)
    return "\n".join(textwrap.wrap(text, 42))

out = ["WEBVTT", ""]
maxlen = 0
for st, en, txt in cues_out:
    w = wrap2(txt)
    maxlen = max(maxlen, max(len(l) for l in w.split("\n")))
    out.append(f"{s2ts(st)} --> {s2ts(en)}")
    out.append(w)
    out.append("")
open(OUT, "w").write("\n".join(out))
n = len(en_blocks)
print(f"blocos com tempo exato por sentenca: {stat_exact}/{n} (proporcional: {stat_prop})")
print(f"cues gerados: {len(cues_out)} | maior linha: {maxlen} chars -> {OUT}")
