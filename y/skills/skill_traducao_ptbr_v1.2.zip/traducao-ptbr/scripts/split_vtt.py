#!/usr/bin/env python3
"""Quebra blocos longos de um VTT em cues curtos (tempo APROXIMADO, proporcional).

Uso: split_vtt.py <entrada.vtt> <saida.vtt>

Atalho quando nao se tem timestamps por palavra: divide cada bloco em sentencas,
distribui a duracao proporcional ao tamanho do texto. Erro de ate ~1s dentro de
blocos de ~30s, ressincronizando nas bordas. Para tempo exato use align_vtt.py.
"""
import re, sys, textwrap

if len(sys.argv) != 3:
    sys.exit(__doc__)
SRC, DST = sys.argv[1], sys.argv[2]

MAX_CHARS = 84
MIN_DUR = 1.0

def ts2s(t):
    h, m, s = t.split(":")
    return int(h)*3600 + int(m)*60 + float(s)

def s2ts(x):
    h = int(x // 3600); x -= h*3600
    m = int(x // 60); x -= m*60
    return f"{h:02d}:{m:02d}:{x:06.3f}"

def sentences(text):
    parts = re.split(r'(?<=[.!?…])\s+', text.strip())
    return [p for p in parts if p]

def split_long(sent):
    if len(sent) <= MAX_CHARS:
        return [sent]
    out, cur = [], ""
    for piece in re.split(r'(?<=,)\s+', sent):
        if cur and len(cur) + 1 + len(piece) > MAX_CHARS:
            out.append(cur); cur = piece
        else:
            cur = f"{cur} {piece}".strip()
    if cur: out.append(cur)
    final = []
    for p in out:
        if len(p) <= MAX_CHARS:
            final.append(p); continue
        words, cur = p.split(), ""
        for w in words:
            if cur and len(cur) + 1 + len(w) > MAX_CHARS:
                final.append(cur); cur = w
            else:
                cur = f"{cur} {w}".strip()
        if cur: final.append(cur)
    return final

def pack(sents):
    chunks, cur = [], ""
    for s in sents:
        for piece in split_long(s):
            if cur and len(cur) + 1 + len(piece) > MAX_CHARS:
                chunks.append(cur); cur = piece
            else:
                cur = f"{cur} {piece}".strip()
    if cur: chunks.append(cur)
    return chunks

def wrap2(text):
    if len(text) <= 42: return text
    for w in range(42, 60):
        lines = textwrap.wrap(text, w)
        if len(lines) <= 2:
            for w2 in range((len(text)+1)//2, w):
                l2 = textwrap.wrap(text, w2)
                if len(l2) == 2: return "\n".join(l2)
            return "\n".join(lines)
    return "\n".join(textwrap.wrap(text, 42))

raw = open(SRC).read()
blocks = re.split(r'\n\n+', raw.strip())
assert blocks[0].strip().startswith("WEBVTT")
cues = []
for b in blocks[1:]:
    lines = b.split("\n")
    m = re.match(r'^(\S+) --> (\S+)$', lines[0])
    if m:
        cues.append((ts2s(m.group(1)), ts2s(m.group(2)), " ".join(lines[1:])))

out = ["WEBVTT", ""]
n = 0
for start, end, text in cues:
    chunks = pack(sentences(text))
    total = sum(len(c) for c in chunks) or 1
    dur = end - start
    t = start
    for i, c in enumerate(chunks):
        share = max(MIN_DUR, dur * len(c) / total)
        cstart = t
        cend = end if i == len(chunks)-1 else min(end, t + share)
        if cend <= cstart: cend = min(end, cstart + MIN_DUR)
        out.append(f"{s2ts(cstart)} --> {s2ts(cend)}")
        out.append(wrap2(c))
        out.append("")
        t = cend
        n += 1

open(DST, "w").write("\n".join(out))
print(f"cues: {len(cues)} -> {n} | saida: {DST}")
