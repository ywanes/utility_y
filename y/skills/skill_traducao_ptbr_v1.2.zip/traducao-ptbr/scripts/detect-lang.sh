#!/bin/bash
set -e
exec > /data/lang.txt 2>&1
pip install --quiet --no-cache-dir faster-whisper >/dev/null 2>&1
python3 - <<'EOF'
from faster_whisper import WhisperModel
model = WhisperModel("tiny", device="cpu", compute_type="int8")
segments, info = model.transcribe("/data/sample.wav")
print(f"LANG={info.language} PROB={info.language_probability:.2f}")
for i, s in enumerate(segments):
    print("SAMPLE:", s.text)
    if i >= 5:
        break
EOF
