---
name: asd-ste100-ptbr
version: 1.0.0
description: Reescreve texto em português do Brasil no estilo ASD-STE100 (Simplified Technical English) adaptado — frases curtas, voz ativa, presente, uma ideia por frase, sem gerúndio, vocabulário controlado (uma palavra = um sentido). Use quando o usuário pedir "português técnico simplificado", "linguagem controlada", "estilo STE/ASD-STE100", ou quiser clarear e desambiguar documentação, afirmativas, premissas, instruções, READMEs, comentários ou textos de painel em pt-BR.
---

# ASD-STE100 pt-BR — Português Técnico Simplificado

Reescreve texto técnico em português do Brasil seguindo uma **adaptação** das regras do ASD-STE100 (Simplified Technical English). O objetivo é **texto claro e sem ambiguidade**, fácil de ler por humano ou por agente.

> **Ressalva:** o ASD-STE100 oficial (Issue 9, 2025) é uma norma **só em inglês**, com dicionário de ~900 palavras aprovadas. Não existe versão oficial em português (ASD/ABNT/ABRAT). Esta skill segue o **espírito** das regras, adaptado à gramática do português — **não** é a norma nem o dicionário oficial.

## Quando usar
- O usuário pede "português técnico simplificado/controlado", "estilo STE" ou "ASD-STE100".
- Há texto ambíguo, longo ou arrastado que precisa ficar claro: afirmativas, premissas, regras de negócio, instruções, passos, README, comentário de código, nota de painel.
- Antes de entregar um texto que um agente vai ler e executar.

## Regras (adaptação pt-BR)

### 1. Frase
- **Uma ideia por frase.** Se tem "e", ";", "porque", "mas" ligando ideias, quebre.
- **Texto descritivo: no máximo 25 palavras por frase. Instrução/passo: no máximo 20.**
- **Um comando por frase** em instrução.
- Comece o parágrafo pela **ideia principal** (frase-tópico).

### 2. Verbo e voz
- **Voz ativa sempre.** Troque "é calculado por X" por "X calcula".
- **Descrição: presente do indicativo.** **Instrução: imperativo** ("Use", "Verifique", "Some").
- **Sem gerúndio** como verbo principal. Troque "aplicando o reajuste" por "aplica o reajuste" ou "para aplicar o reajuste".
- Evite futuro do subjuntivo e tempos compostos longos ("terá sido feito").

### 3. Palavras
- **Uma palavra = um sentido.** Escolha um termo e repita. Não alterne sinônimos (fixe "reajuste"; não use "correção/aumento/índice" como se fossem iguais).
- **Prefira a palavra simples** (tabela em `references/regras.md`): usar, fazer, ter, cerca de, verificar, mostrar.
- **Sem nominalização pesada:** "a realização do cálculo" → "calcular".
- **Grupo de substantivos com no máximo 3 palavras.**

### 4. Estrutura e clareza
- Use **artigos e conectivos**. Não telegrafe ("remover filtro" → "remova o filtro").
- Use **lista** para passos, condições ou itens.
- **Defina o termo técnico uma vez** e depois use sempre igual.
- Números em **algarismos**: "5%", "12 meses", "6 contratos".

### 5. Armadilhas do português (desambiguar)
- **"deixar de"** → "parar de" ou "não" ("deixou de reajustar" → "não reajustou").
- **"mesmo", "a mesma"** ambíguo → nomeie o item.
- **"a partir de"** → só para data/ponto no tempo ("a partir de jan/27"), não para causa.
- **"que" empilhado** → quebre em duas frases.
- **Sujeito oculto (pro-drop):** em instrução ou quando houver dúvida, deixe o sujeito/objeto explícito.

## Processo (como reescrever)
1. **Quebre** as frases longas em frases de uma ideia.
2. **Converta** para voz ativa + presente (descrição) ou imperativo (instrução).
3. **Remova** gerúndios e nominalizações.
4. **Padronize** o vocabulário: um termo por conceito; palavra simples.
5. **Resolva** as armadilhas pt-BR da seção 5.
6. **Confira** o limite de palavras por frase (25 descritivo / 20 instrução).
7. Preserve **números, nomes próprios e termos técnicos** do original — clareza é forma, não muda o conteúdo.

## Exemplo (antes → depois)

**Antes (1 frase, 34 palavras):**
> "O reajuste de 2026 já aplicado está na base (jul–set), projetá-lo de novo contaria duas vezes; por isso o upside de reajuste vem só dos contratos vencidos e os demais entram a 0%."

**Depois (3 frases, voz ativa, presente):**
> - O reajuste de 2026 já está na base (jul–set).
> - O modelo não aplica esse reajuste outra vez.
> - O ganho de reajuste vem só dos contratos vencidos; os demais entram a 0%.

Mais substituições e exemplos em `references/regras.md`.
