# Referência — ASD-STE100 pt-BR

Apoio à `SKILL.md`: tabela de palavras, correções de gerúndio, armadilhas e um exemplo completo.

## 1. Palavra difícil → palavra simples
Escolha a forma da direita. Use sempre a mesma para o mesmo sentido.

| Evite | Use |
|---|---|
| utilizar, fazer uso de | usar |
| efetuar, realizar, executar (sentido geral) | fazer |
| possuir, dispor de | ter |
| aproximadamente, por volta de | cerca de |
| averiguar, aferir, constatar | verificar |
| demonstrar, evidenciar, exibir | mostrar |
| necessitar de, carecer de | precisar de |
| proceder à análise de | analisar |
| a realização de, a execução de | (verbo direto: realizar → fazer) |
| no sentido de, com o intuito de | para |
| em virtude de, tendo em vista que | porque |
| caso (condição) | se |
| anteriormente, previamente | antes |
| posteriormente | depois |
| a totalidade de | todo / todos |
| um elevado número de | muitos |
| na eventualidade de | se |
| de modo a | para |

## 2. Gerúndio → forma simples
O gerúndio ("-ndo") como verbo principal deixa a frase vaga. Troque:

| Evite | Use |
|---|---|
| "aplicando o reajuste, o saldo sobe" | "quando aplica o reajuste, o saldo sobe" |
| "o sistema está calculando o lump" | "o sistema calcula o lump" |
| "para reajustar, somando os ciclos" | "para reajustar, some os ciclos" |
| "visando reduzir o custo" | "para reduzir o custo" |

Exceção: gerúndio é aceitável em locução que indica ação simultânea real e curta, mas prefira sempre a forma simples.

## 3. Armadilhas do português (desambiguação)
| Construção | Problema | Correção |
|---|---|---|
| "deixou de reajustar" | "deixar de" = parar OU esquecer | "não reajustou" / "parou de reajustar" |
| "a mesma foi aplicada" | "a mesma" refere a quê? | nomeie: "a regra foi aplicada" |
| "a partir disso" | vira causa vaga | use só para tempo: "a partir de jan/27" |
| "o contrato que vence que tem cláusula que..." | "que" empilhado | quebre em frases curtas |
| "reajustar os valores" (quem?) | sujeito oculto | "o financeiro reajusta os valores" |
| "pode não ser aplicado" | dupla negação/modal vago | "o sistema talvez não aplica" ou afirme |

## 4. Limite de palavras
- **Descritivo:** até 25 palavras por frase.
- **Instrução / passo:** até 20 palavras por frase.
- Se passar do limite, quebre por ideia — não corte palavras necessárias (não telegrafe).

## 5. Checklist rápido
1. Uma ideia por frase?
2. Voz ativa?
3. Presente (descrição) ou imperativo (instrução)?
4. Sem gerúndio como verbo principal?
5. Mesmo termo para o mesmo conceito?
6. Palavra simples (tabela 1)?
7. Artigos e conectivos presentes?
8. Dentro do limite de palavras?
9. Números, nomes e termos técnicos preservados?

## 6. Exemplo completo (afirmativas de painel)

**Antes:**
> "Reajuste é anual: contrato parado mais de 12 meses acumula mais de um reajuste. O painel aplica um ciclo por aniversário, cada um retroativo à sua data (ex.: 21 meses = 2 reajustes, a 21 e a 9 meses atrás), compostos (1,05² ≈ +10,25%)."

**Depois (STE pt-BR):**
> - O reajuste é anual.
> - Um contrato parado por mais de 12 meses acumula mais de um reajuste.
> - O painel aplica um ciclo por aniversário.
> - Cada ciclo é retroativo à sua data. Exemplo: 21 meses geram 2 reajustes, a 21 e a 9 meses atrás.
> - Os reajustes compõem: 1,05 × 1,05 ≈ +10,25%.

**Antes:**
> "O repasse do reajuste ao médico entra como 0% por padrão: o reajuste é entre a BNG e o contratante, e o médico é pago por escala (negociado à parte), então não há passagem automática."

**Depois (STE pt-BR):**
> - Por padrão, o médico recebe 0% do reajuste.
> - O reajuste é entre a BNG e o contratante.
> - A BNG paga o médico por escala, em acordo separado.
> - Por isso o reajuste não vai ao médico de forma automática.

## 7. Nota de conformidade
O ASD-STE100 oficial é só inglês e usa um dicionário fechado de ~900 palavras aprovadas. Esta skill **não** replica esse dicionário; ela aplica as regras de estrutura e estilo adaptadas ao português. Para conformidade formal com a norma, o texto teria de ser em inglês e passar pelo dicionário oficial.
