package com.jcraft.jsch.jcraft;

public class Compression implements com.jcraft.jsch.Compression {

    @Override
    public void init(int type, int level) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public byte[] compress(byte[] buf, int start, int[] len) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public byte[] uncompress(byte[] buf, int start, int[] len) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
